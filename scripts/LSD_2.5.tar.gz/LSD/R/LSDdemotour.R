

###########################################################
### LSD demo tour: compilation of several plot examples ###
###########################################################


### LSD.demo.tour ###


LSD.demo.tour = function()
{
	demo.clusterplot()
	demo.heatscatter()
	demo.heatpairs()
	demo.heatboxplot()
	demo.linesplot()
	demo.heathist()
	demo.msdplot()
	demo.comparisonplot()
	demo.LSDpie()
	demo.plotmatrix()
	demo.makemovie()
	disco()
	demo.distinctcolors()
	demo.convertcolor()
	demo.heatmaplot()
	demo.heatmapairs()
	demo.ellipsescatter()
	LSDshow("try the plotit function")
}


#LSD.demo.tour()



